import os
import json
from pymongo import MongoClient

# MongoDB에 연결
client = MongoClient('mongodb://<사용자 이름>:<비밀번호>@<호스트>:<포트>/')

# 데이터베이스 선택
db = client['ibalance']

# 현재 디렉토리에 있는 JSON 파일 목록 가져오기
json_files = [f for f in os.listdir('.') if os.path.isfile(f) and f.endswith('.json')]

# 각 JSON 파일을 해당하는 컬렉션에 import
for json_file in json_files:
    collection_name = os.path.splitext(json_file)[0]  # 파일명에서 확장자 제거하여 컬렉션 이름으로 사용
    collection = db[collection_name]

    # JSON 파일에서 데이터 읽기
    with open(json_file, 'r') as f:
        data = json.load(f)

    # 데이터를 컬렉션에 삽입
    collection.insert_many(data)

print("JSON 파일을 MongoDB에 import했습니다.")
